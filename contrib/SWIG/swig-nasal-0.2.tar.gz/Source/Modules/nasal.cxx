/********************************************************************
 * Nasal module for SWIG
 *
 *  Manabu NISHIYAMA
 ********************************************************************/

#include "swigmod.h"
#define SWIG_PROTECTED_TARGET_METHODS 1

#ifndef MACSWIG
#include "swigconfig.h"
#endif

#include <ctype.h>
#include <string.h>
#include <limits.h> /* for INT_MAX */

static const char *
usage = "\
Nasal Options (available with -nasal)\n\
";

class NASAL : public Language {
private:

  String *PrefixPlusUnderscore;
  String *module;
  String *methods;
  String *constants;
  int current;

  File *f_runtime;
  File *f_runtime_h;
  File *f_header;
  File *f_wrappers;
  File *f_init;

  bool use_kw;

  // Wrap modes
  enum {
    NO_CPP,
    MEMBER_FUNC,
    CONSTRUCTOR,
    DESTRUCTOR,
    MEMBER_VAR,
    CLASS_CONST,
    STATIC_FUNC,
    STATIC_VAR
  };

public:

  /* ---------------------------------------------------------------------
   * NASAL()
   *
   * Initialize member data
   * --------------------------------------------------------------------- */

  NASAL() {
    module = 0;
    methods = 0;
    constants = 0;
    current = NO_CPP;
    f_runtime = 0;
    f_header = 0;
    f_wrappers = 0;
    f_init = 0;
    use_kw = false;
  }
  
  /* ---------------------------------------------------------------------
   * main()
   *
   * Parse command line options and initializes variables.
   * --------------------------------------------------------------------- */

  virtual void main(int argc, char *argv[]) {

    /* Set location of SWIG library */
    SWIG_library_directory("nasal");
    
    /* Look for certain command line options */
    for (int i = 1; i < argc; i++) {
      if (argv[i]) {
	if (strcmp(argv[i],"-help") == 0) {
	  Printf(stderr, "%s\n", usage);
	}
      }
    }

    /* Add a symbol to the parser for conditional compilation */
    Preprocessor_define("SWIGNASAL 1", 0);
    
    /* Add typemap definitions */
    SWIG_typemap_lang("nasal");
    SWIG_config_file("nasal.swg");
    allow_overloading();
  }

  /* ---------------------------------------------------------------------
   * top()
   * --------------------------------------------------------------------- */

  virtual int top(Node *n) {

    Node *swigModule = Getattr(n, "module");
    if (swigModule) {
      Node *options = Getattr(swigModule, "options");
      if (options) {
	if (Getattr(options, "dirprot")) {
          allow_dirprot();
	}
      }
    }

    /* Initialize all of the output files */
    String *outfile = Getattr(n, "outfile");

    f_runtime = NewFile(outfile, "w");
    if (!f_runtime) {
      Printf(stderr,"*** Can't open '%s'\n", outfile);
      SWIG_exit(EXIT_FAILURE);
    }


    f_init = NewString("");
    f_header = NewString("");
    f_wrappers = NewString("");
    methods = NewString("");
    constants = NewString("");

    /* Register file targets with the SWIG file handler */
    Swig_register_filebyname("header", f_header);
    Swig_register_filebyname("wrapper", f_wrappers);
    Swig_register_filebyname("runtime", f_runtime);
    Swig_register_filebyname("init", f_init);

    /*
    modvar = 0;
    current = NO_CPP;
    klass = 0;
    classes = NewHash();
    
    registerMagicMethods();
    */

    Swig_banner(f_runtime);


    /* typedef void *VALUE */
    /*
    SwigType *value = NewSwigType(T_VOID);
    SwigType_add_pointer(value);
    SwigType_typedef(value,(char*)"VALUE");
    Delete(value);
    */

    /* Set module name */
    module = Getattr(n,"name");

    //
    //----------------------------------------------------------
    //

    Printf(f_header,"#define SWIG_init    naInit_%s\n", module);
    Printf(f_header,"#define SWIG_name    \"%s\"\n\n", module);

    /* Start generating the initialization function */
    //Printf(f_header, "#define NASTR(s) naStr_fromdata(naNewString(c), (s), strlen((s)))\n\n");

    Printf(f_header, "typedef struct{\n");
    Printf(f_header, "    char *name;\n");
    Printf(f_header, "    naCFunction addr;\n");
    Printf(f_header, "    char type;\n");
    Printf(f_header, "} naMethodDef;\n\n");

    Printf(methods, "static naMethodDef SwigMethods[] = {\n");
    Language::top(n);
    Printf(methods, "    {0, 0, 0}\n");
    Printf(methods, "};\n");


    Printf(f_wrappers,"%s\n", methods);
    
    Printv(f_init,
	   "\n",
	   "#ifdef __cplusplus\n",
	   "extern \"C\"\n",
	   "#endif\n",
	   "SWIGEXPORT naRef naInit_", module,
	   "(naContext c) {\n",
	   "naRef nspace = naNewHash(c);\n",
	   "naRef klass, parents;\n",
	   "int i;\n",
	   "\n",
	   NIL);

    //Printv(f_init,
    //	   "\n",
    //   "for (i = 0; swig_types_initial[i]; i++) {\n",
    //   "swig_types[i] = SWIG_TypeRegister(swig_types_initial[i]);\n",
    //   "}\n\n",
    //   NIL);

    Printf(f_init, "for(i=0; SwigMethods[i].type != 0; i++) {\n");
    Printf(f_init, "switch(SwigMethods[i].type) {\n");
    Printf(f_init, "case 'f':\n");
    Printf(f_init, "naHash_set(nspace, NASTR(c, SwigMethods[i].name), naNewFunc(c, naNewCCode(c, SwigMethods[i].addr)));\n");
    Printf(f_init, "break;\n\n");
    Printf(f_init, "case 'c':\n");
    Printf(f_init, "klass = naNewHash(c);\n");
    Printf(f_init, "naHash_set(nspace, NASTR(c, SwigMethods[i].name), klass);\n");
    Printf(f_init, "break;\n\n");
    Printf(f_init, "case 'i':\n");
    Printf(f_init, "klass = naNewHash(c);\n");
    Printf(f_init, "parents = naNewVector(c);\n");
    Printf(f_init, "naHash_set(nspace, NASTR(c, SwigMethods[i].name), klass);\n");
    Printf(f_init, "naHash_set(klass, NASTR(c, \"parents\"), parents);\n");
    Printf(f_init, "break;\n\n");
    Printf(f_init, "case 'b':\n");
    Printf(f_init, "naVec_append(parents, naHash_cget(nspace, SwigMethods[i].name));\n");
    Printf(f_init, "break;\n\n");
    Printf(f_init, "case 'm':\n");
    Printf(f_init, "naHash_set(klass, NASTR(c, SwigMethods[i].name), naNewFunc(c, naNewCCode(c, SwigMethods[i].addr)));\n");
    Printf(f_init, "break;\n\n");
    Printf(f_init, "}\n");
    Printf(f_init, "}\n\n");

    Printf(f_init, "%s\n\n", constants);
    Printv(f_init, "return nspace;\n", NIL);

    /* Finish off our init function */
    Printf(f_init,"}\n");
    SwigType_emit_type_table(f_runtime,f_wrappers);

    /* Close all of the files */
    Dump(f_header,f_runtime);

    Dump(f_wrappers,f_runtime);
    Wrapper_pretty_print(f_init,f_runtime);

    Delete(f_header);
    Delete(f_wrappers);
    Delete(f_init);
    Close(f_runtime);
    Delete(f_runtime);

    return SWIG_OK;
  }

  /* -----------------------------------------------------------------------------
   * importDirective()
   * ----------------------------------------------------------------------------- */
  
  virtual int importDirective(Node *n) {
    return Language::importDirective(n);
  }

  
  /* ------------------------------------------------------------
   * strip()
   *
   * For names that begin with the current class prefix plus an
   * underscore (e.g. "Foo_enum_test"), return the base function
   * name (i.e. "enum_test").
   * ------------------------------------------------------------ */

  String *strip(const String_or_char *name) {
    String *s = Copy(name);
    if (Strncmp(name, PrefixPlusUnderscore, Len(PrefixPlusUnderscore)) != 0) {
      return s;
    }
    Replaceall(s, PrefixPlusUnderscore, "");
    return s;
  }


  /* ---------------------------------------------------------------------
   * create_command(Node *n, char *iname)
   *
   * Creates a new command from a C function.
   *              iname = Name of function in scripting language
   *
   * --------------------------------------------------------------------- */

  void create_command(Node *n, const String_or_char *iname) {
  //------------------------------------------------------------koko

    String *wname = Swig_name_wrapper(iname);
    String *rename = 0;
    
    switch (current) {
    case NO_CPP:
      Printv(methods, tab4, "{\"", iname, "\",\t", wname, ",\t'f'},\n", NIL);
      break;
    case STATIC_FUNC:
    case STATIC_VAR:
      rename = strip(iname);
      Printv(methods, tab4, "{\"", rename, "\",\t", wname, ",\t'm'},\n", NIL);
      break;
    case CONSTRUCTOR:
    case DESTRUCTOR:
      rename = strip(iname);
      Printv(methods, tab4, "{\"", rename, "\",\t", wname, ",\t'm'},\n", NIL);
      break;
    case MEMBER_FUNC: 
    case MEMBER_VAR:
      rename = strip(iname);
      Printv(methods, tab4, "{\"", rename, "\",\t", wname, ",\t'm'},\n", NIL);
      break;
    case CLASS_CONST:
      assert(false); // Should not have gotten here for these types
    default:
      assert(false); // what is this?
    }
    
    Delete(wname);
    Delete(rename);
  }
  
  /* ---------------------------------------------------------------------
   * validIdentifier()
   *
   * Is this a valid identifier in the scripting language?
   * --------------------------------------------------------------------- */

  virtual int validIdentifier(String *s) {
    char *c = Char(s);
    while (*c) {
      if (!(isalnum(*c)||(*c == '_'))) return 0;
      c++;
    }
    return 1;
  }
  
  /* ---------------------------------------------------------------------
   * functionWrapper()
   *
   * Create a function declaration and register it with the interpreter.
   * --------------------------------------------------------------------- */

  virtual int functionWrapper(Node *n) {
    String *nodeType;
    bool constructor;
    bool destructor;
    String *storage;
    bool isVirtual;

    String *symname = Copy(Getattr(n,"sym:name"));
    SwigType *t = Getattr(n,"type");
    ParmList *l = Getattr(n,"parms");
    String *tm;

    Parm    *p;
    int i, j;
    
    nodeType = Getattr(n, "nodeType");
    constructor = (!Cmp(nodeType, "constructor")); 
    destructor = (!Cmp(nodeType, "destructor")); 
    storage   = Getattr(n, "storage");
    isVirtual = (Cmp(storage, "virtual") == 0);

    String *overname = 0;
    if (Getattr(n, "sym:overloaded")) {
      overname = Getattr(n, "sym:overname");
    } else {
      if (!addSymbol(symname, n))
        return SWIG_ERROR;
    }

    String *cleanup = NewString("");
    String *outarg = NewString("");
    String *kwargs = NewString("");
    String *target = NewString("");
    String *source = NewString("");
    Wrapper *fs[] = {NewWrapper(), NewWrapper()};
    Wrapper *f = fs[0];

    /* Determine the name of the SWIG wrapper function */
    String *wname = Swig_name_wrapper(symname);
    if (overname) {
      Append(wname,overname);
    }
  

    /* Attach standard typemaps */
    emit_attach_parmmaps(l, f);
    Setattr(n, "wrap:parms", l);

    /* Get number of arguments */
    int  numarg = emit_num_arguments(l);
    int  numreq = emit_num_required(l);
    int  varargs = emit_isvarargs(l);
    bool allow_kwargs = use_kw || Getattr(n,"feature:kwargs");
    int start = (current == MEMBER_FUNC || current == MEMBER_VAR
		 || current == DESTRUCTOR) ? 1:0;
    //int num_func = (current == CONSTRUCTOR || current == DESTRUCTOR) ? 2:1;
    int num_func = 1;

    if(!Getattr(n,"feature:revcall")){
      emit_args(t,l,f);

      /* Attach standard typemaps */
      emit_attach_parmmaps(l, f);
      Setattr(n, "wrap:parms", l);

      for(j=0; j<num_func; j++){
	f = fs[j];
	/* Now write the wrapper function itself */
	Printv(f->def, "static naRef ", wname, "(naContext c, naRef me, int argc, naRef *args){", NIL);
	if(numreq-start>0){
	  Printf(f->code,"if (argc < %d){\n", numreq-start);
	  Printf(f->code,"naRuntimeError(c, \"wrong number of arguments.  %d expected.\\n\");\n", numreq-start);
	  Printf(f->code,"}\n");
	}
    

	/* Now walk the function parameter list and generate code */
	/* to get arguments */

	Printf(kwargs,"{ ");  
	for (i = 0, p=l; i < numarg; i++) {
    
	  while (checkAttribute(p,"tmap:in:numinputs","0")) {
	    p = Getattr(p,"tmap:in:next");
	  }

	  SwigType *pt = Getattr(p,"type");
	  String   *pn = Getattr(p,"name");
	  String   *ln = Getattr(p,"lname");
	  Clear(source);

	  if(i==0 && start==1){
	    Printf(source, "me");
	  }else{
	    Printf(source, "args[%d]", i-start);
	  }

	  Clear(target);
	  Printf(target,"%s",Char(ln));

	  if (i >= (numreq)) { /* Check if parsing an optional argument */
	    //Wrapper_add_local(f, "argc", "int argc = naVec_size(args)");
	    Printf(f->code, "if (argc > %d) ", i-start);
	  }

	  /* Keyword argument handling */
	  if (Len(pn)) {
	    Printf(kwargs,"\"%s\",", pn);
	  } else {
	    Printf(kwargs,"\"arg%d\",", i+1);
	  }

	  /* Look for an input typemap */
	  if ((tm = Getattr(p,"tmap:in"))) {
	    Replaceall(tm,"$source",source);
	    Replaceall(tm,"$target",ln);
	    Replaceall(tm,"$input", source);
	    Setattr(p,"emit:input", Copy(source));
	  
	    Printf(f->code,"%s\n", tm);
	    p = Getattr(p,"tmap:in:next");
	    continue;
	  } else {
	    Swig_warning(WARN_TYPEMAP_IN_UNDEF, input_file, line_number, 
			 "Unable to use type %s as a function argument.\n",SwigType_str(pt,0));
	    break;
	  }
	  p = nextSibling(p);
	}

	Printf(kwargs," NULL }");

	if (allow_kwargs) {
	  Printv(f->locals, tab4, "char *kwnames[] = ", kwargs, ";\n", NIL);
	}

	/* Trailing varargs */
	if (varargs) {
	  if (p && (tm = Getattr(p,"tmap:in"))) {
	    Clear(source);
	    Printf(source,"args[%d]",i-start);
	    Replaceall(tm,"$input",source);
	    Setattr(p,"emit:input",Copy(source));
	    Printf(f->code,"if (argc > %d) {\n", i-start);
	    Printv(f->code,tm,"\n",NIL);
	    Printf(f->code,"}\n");
	  }
	}

	/* needs object */
	if(start != 0){
	  Printf(f->code, "if (!arg1) {\n");
	  Printf(f->code,"naRuntimeError(c, \"cannot access to the object.\\n\");\n");
	  Printf(f->code,"}\n");
	}

	/* Insert constraint checking code */
	for (p = l; p;) {
	  if ((tm = Getattr(p,"tmap:check"))) {
	    Replaceall(tm,"$target",Getattr(p,"lname"));
	    Printv(f->code,tm,"\n",NIL);
	    p = Getattr(p,"tmap:check:next");
	  } else {
	    p = nextSibling(p);
	  }
	}

	/* Insert cleanup code */
	for (p = l; p;) {
	  if ((tm = Getattr(p,"tmap:freearg"))) {
	    Replaceall(tm,"$source",Getattr(p,"lname"));
	    Printv(cleanup,tm,"\n",NIL);
	    p = Getattr(p,"tmap:freearg:next");
	  } else {
	    p = nextSibling(p);
	  }
	}

	/* Insert argument output code */
	for (p = l; p;) {
	  if ((tm = Getattr(p,"tmap:argout"))) {
	    Replaceall(tm,"$source",Getattr(p,"lname"));
	    Replaceall(tm,"$target","resultobj");
	    Replaceall(tm,"$arg",Getattr(p,"emit:input"));
	    Replaceall(tm,"$input",Getattr(p,"emit:input"));
	    Printv(outarg,tm,"\n",NIL);
	    p = Getattr(p,"tmap:argout:next");
	  } else {
	    p = nextSibling(p);
	  }
	}

	/* Emit the function call */
	emit_action(n,f);

	/* Return value if necessary */
	if ((tm = Swig_typemap_lookup_new("out",n,"result",0))) {
	  Replaceall(tm,"$source", "result");
	  Replaceall(tm,"$target", "resultobj");
	  Replaceall(tm,"$result", "resultobj");
	  if (Getattr(n,"feature:new")) {
	    Replaceall(tm,"$owner","1");
	  } else {
	    Replaceall(tm,"$owner","0");
	  }
      
	  Printf(f->code,"%s\n", tm);
	} else {
	  Swig_warning(WARN_TYPEMAP_OUT_UNDEF, input_file, line_number,
		       "Unable to use return type %s in function %s.\n",
		       SwigType_str(t,0), symname);
	}

	if (current == CONSTRUCTOR) {
	  Printv(f->code, "\n", "obj = naNewHash(c);\n", NIL);
	  Printv(f->code, "parents = naNewVector(c);\n", NIL);
	  Printv(f->code, "naVec_append(parents, me);\n", NIL);
	  Printv(f->code, "naHash_set(obj, NASTR(c, \"parents\"), parents);\n", NIL);
	  Printv(f->code, "naHash_set(obj, NASTR(c, PTR_NAME), resultobj);\n", NIL);
	}else if(current == DESTRUCTOR){
	  Printv(f->code, "naHash_set(me, NASTR(c, \"delete\"), naNil());\n", NIL);
	}

	/* Dump argument output code; */
	Printv(f->code,outarg,NIL);

	/* Dump the argument cleanup code */
	Printv(f->code,cleanup,NIL);

	/* Look to see if there is any newfree cleanup code */
	if (Getattr(n,"feature:new")) {
	  if ((tm = Swig_typemap_lookup_new("newfree",n,"result",0))) {
	    Replaceall(tm,"$source","result");
	    Printf(f->code,"%s\n",tm);
	  }
	}
    
	if (current == CONSTRUCTOR && Getattr(n,"feature:startup")) {
	  Printv(f->code, "\n", NIL);
	  Printv(f->code, Getattr(n,"feature:startup"), "\n\n", NIL);
	}
    
	/* Special processing on return value. */
	if ((tm = Swig_typemap_lookup_new("ret",n,"result",0))) {
	  Replaceall(tm,"$source","result");
	  Printv(f->code,tm, NIL);
	}

	/* Wrap things up (in a manner of speaking) */
	Wrapper_add_local(f, "resultobj", "naRef resultobj");
	if(current != CONSTRUCTOR){
	  Printv(f->code, tab4, "return resultobj;\n", NIL);
	}else{
	  Wrapper_add_local(f, "obj, parents", "naRef obj, parents");
	  Printv(f->code, tab4, "return obj;\n", NIL);
	}

	Printf(f->code,"}\n");
      }
      f = fs[0];
      
    }else{
      Printv(f->def, "***\n", NIL);
      Printv(f->def, SwigType_str(t,0), " ", Getattr(parentNode(n), "name"), "::", SwigType_str(Getattr(n, "name"),0), "(", NIL);

      //SwigType *t = Getattr(n,"type");
      // Now walk the function parameter list and generate code to get arguments

      Wrapper_add_local(f, "args", "naRef args = naNil()");
      if(start != 0){
	Wrapper_add_local(f, "me", "naRef me = naNil()");
	if (Getattr(n,"feature:meref")) {
	  Printv(f->code, Getattr(n,"feature:meref"), "\n", NIL);
	}
      }

      
      for (i = 0, p=l; i < numarg; i++) {

	while (checkAttribute(p,"tmap:in:numinputs","0")) {
	  p = Getattr(p,"tmap:in:next");
	}

	SwigType *pt = Getattr(p,"type");
	String   *ln = Getattr(p,"lname");
	String   *ln2 = NewString("");

	Printf(ln2,"naRef %s = naNil()", ln);
	Wrapper_add_local(f, ln, ln2);
	Delete(ln2);

	if(i > start) Printv(f->def, ", ", NIL);
	if(i < start){
	  p = Getattr(p,"tmap:in:next");
	  continue;
	}
	
	String   *arg = NewString("");


       	Printf(arg,"c%s", ln);

	// Add parameter to C function
	Printv(f->def, SwigType_str(pt,0), " ", arg, NIL);

	/* Look for an input typemap */
	if ((tm = Swig_typemap_lookup_new("out",p,arg,0))) {
	//if ((tm = Getattr(p,"tmap:in"))) {
	  Replaceall(tm,"$result", ln);
	  
	  Printf(f->code,"%s\n", tm);
	} else {
	  Swig_warning(WARN_TYPEMAP_IN_UNDEF, input_file, line_number, 
		       "Unable to use type %s as a function argument.\n", SwigType_str(pt,0));
	  break;
	}

	p = Getattr(p,"tmap:in:next");
	Delete(arg);

      }
      Printv(f->def, "){\n", NIL);


      /* Emit the function call */
      emit_action(n,f);

      Printv(f->code, "}\n", NIL);
    }

    /* Substitute the cleanup code */
    Replaceall(f->code,"$cleanup",cleanup);

    /* Substitute the function name */
    Replaceall(f->code,"$symname", symname);
    Replaceall(f->code,"$result", "resultobj");

    /* Emit the function */
    Wrapper_print(fs[0], f_wrappers);
    if(num_func > 1) Wrapper_print(fs[1], f_wrappers);
    
    /* Now register the function with the interpreter */
    if (!Swig_symbol_isoverloaded(n)) {
      create_command(n, symname);
    } else {
      Setattr(n, "wrap:name", wname);
      if (!Getattr(n, "sym:nextSibling"))
	dispatchFunction(n);
    }
    
    Delete(source);
    Delete(target);
    Delete(kwargs);
    Delete(cleanup);
    Delete(outarg);
    Delete(symname);
    DelWrapper(fs[0]);
    DelWrapper(fs[1]);
  
    return SWIG_OK;
  }

  /* ------------------------------------------------------------
   * dispatchFunction()
   * ------------------------------------------------------------ */
   
  void dispatchFunction(Node *n) {
    /* Last node in overloaded chain */

    int maxargs;
    int start = (current == MEMBER_FUNC || current == MEMBER_VAR
		 || current == DESTRUCTOR) ? 1:0;
    String *tmp = NewString("");
    String *dispatch = Swig_overload_dispatch(n, "return %s(c, me, args);",
					      &maxargs);
	
    /* Generate a dispatch wrapper for all overloaded functions */

    Wrapper *f       = NewWrapper();
    String  *symname = Getattr(n, "sym:name");
    String  *wname   = Swig_name_wrapper(symname);

    Printv(f->def, "static naRef ", wname, "(naContext c, naRef me, int argc, naRef *args){", NIL);
    
    Printf(tmp, "naRef argv[%d]", maxargs);
    Wrapper_add_local(f, "argv", tmp);
    Wrapper_add_local(f, "ii", "int ii");
    if(start==1){
      Printf(f->code, "for (ii = 0; (ii < argc) && (ii < %d); ii++) {\n", maxargs+1);
      Printf(f->code, "argv[ii] = args[ii];\n");
      Printf(f->code, "}\n");
    }else{
      Printf(f->code, "for (ii = 0; (ii < argc) && (ii < %d); ii++) {\n", maxargs);
      Printf(f->code, "argv[ii] = args[ii];\n");
      Printf(f->code, "}\n");
    }
    Replaceall(dispatch, "$args", "c, me, args");
    Printv(f->code, dispatch, "\n", NIL);
    Printf(f->code, "naRuntimeError(c, \"No matching function for overloaded '%s'\"\n);\n", symname);
    Printf(f->code,"return naNil();\n");
    Printv(f->code, "}\n", NIL);
    Wrapper_print(f, f_wrappers);
    create_command(n, symname);

    DelWrapper(f);
    Delete(dispatch);
    Delete(wname);
  }
  
  /* ---------------------------------------------------------------------
   * variableWrapper()
   * --------------------------------------------------------------------- */

  virtual int variableWrapper(Node *n) {
    return Language::variableWrapper(n);
  }
  
  /* ---------------------------------------------------------------------
   * constantWrapper()
   * --------------------------------------------------------------------- */

  virtual int constantWrapper(Node *n) {
    Swig_require("constantWrapper",n, "*sym:name", "type", "value", NIL);
    
    String *iname   = Getattr(n,"sym:name");
    SwigType *type  = Getattr(n,"type");
    char *value     = GetChar(n,"value");
    
    if (current == CLASS_CONST) {
      iname = strip(iname);
    }else{
      iname = Copy(iname);
    }
    
    /* Special hook for member pointer */
    if (SwigType_type(type) == T_MPOINTER) {
      String *wname = Swig_name_wrapper(iname);
      Printf(f_header, "static %s = %s;\n", SwigType_str(type, wname), value);
      value = Char(wname);
    }

    /* Perform constant typemap substitution */
    String *tm = Swig_typemap_lookup_new("constant", n, value, 0);
    if (tm) {
      Replaceall(tm, "$source", value);
      Replaceall(tm, "$target", iname);
      Replaceall(tm, "$symname", iname);
      Replaceall(tm, "$value", value);
      Printv(constants, tm, "\n", NIL);
    } else {
      Swig_warning(WARN_TYPEMAP_CONST_UNDEF, input_file, line_number,
		   "Unsupported constant value %s = %s\n", SwigType_str(type, 0), value);
    }

    Delete(iname);
    Swig_restore(n);
    return SWIG_OK;
  }
  
  /* --------------------------------------------------------------------------
   * nativeWrapper()
   * -------------------------------------------------------------------------- */
  virtual int nativeWrapper(Node *n) {
    String *name = Getattr(n,"sym:name");
    create_command(n, name);
    return SWIG_OK;
  }

  /* -----------------------------------------------------------------------------
   * classDeclaration() 
   *
   * Records information about classes---even classes that might be defined in
   * other modules referenced by %import.
   * ----------------------------------------------------------------------------- */

  virtual int classDeclaration(Node *n) {
    return Language::classDeclaration(n);
  }
  
  /* ----------------------------------------------------------------------
   * classHandler()
   * ---------------------------------------------------------------------- */

  virtual int classHandler(Node *n) {

    String *symname = Getattr(n,"sym:name");

    PrefixPlusUnderscore = NewStringf("%s_", getClassPrefix());

    //クラスごとに１度呼ばれる

    /* Handle inheritance */
    List *baselist = Getattr(n,"bases");
    if (baselist && Len(baselist) > 0) {
      Iterator base = First(baselist);
      Printv(methods, tab4, "{\"", symname, "\",\t0,\t'i'},\n", NIL);
      while (base.item) {
        String *basename = Getattr(base.item,"name");
	Printv(methods, tab4, "{\"", basename, "\",\t0,\t'b'},\n", NIL);
        base = Next(base);
      }
    }else{
      Printv(methods, tab4, "{\"", symname, "\",\t0,\t'c'},\n", NIL);
    }

    Language::classHandler(n);

    SwigType *tt = NewString(symname);
    SwigType_add_pointer(tt);
    SwigType_remember(tt);
    String *tm = SwigType_manglestr(tt);
    //    Printf(f_init, "SWIG_TypeClientData(SWIGTYPE%s, (void *) &%s);\n", tm, symname);
    Delete(tm);
    Delete(tt);

    Delete(PrefixPlusUnderscore); PrefixPlusUnderscore = 0;

    return SWIG_OK;
  }

  /* ----------------------------------------------------------------------
   * memberfunctionHandler()
   *
   * Method for adding C++ member function
   *
   * By default, we're going to create a function of the form :
   *
   *         Foo_bar(this,args)
   *
   * Where Foo is the classname, bar is the member name and the this pointer
   * is explicitly attached to the beginning.
   *
   * The renaming only applies to the member function part, not the full
   * classname.
   *
   * --------------------------------------------------------------------- */
  
  virtual int memberfunctionHandler(Node *n) {
    current = MEMBER_FUNC;
    Language::memberfunctionHandler(n);
    current = NO_CPP;
    return SWIG_OK;
  }
  
  /* ---------------------------------------------------------------------
   * constructorHandler()
   *
   * Method for adding C++ member constructor
   * -------------------------------------------------------------------- */

  virtual int constructorHandler(Node *n) {
    /* First wrap the allocate method */
    current = CONSTRUCTOR;
    Swig_name_register((String_or_char *) "construct", (String_or_char *) "%c_new");
    Language::constructorHandler(n);


    /* Done */
    Swig_name_unregister((String_or_char *) "construct");

    current = NO_CPP;
    return SWIG_OK;
  }

  /* ---------------------------------------------------------------------
   * destructorHandler()
   * -------------------------------------------------------------------- */

  virtual int destructorHandler(Node *n) {
    current = DESTRUCTOR;
    Swig_name_register((String_or_char *) "destroy", (String_or_char *) "%c_delete");
    Language::destructorHandler(n);

    /* Done */
    Swig_name_unregister((String_or_char *) "destroy");

    current = NO_CPP;
    return SWIG_OK;
  }

  /* ---------------------------------------------------------------------
   * membervariableHandler()
   *
   * This creates a pair of functions to set/get the variable of a member.
   * -------------------------------------------------------------------- */

  virtual int membervariableHandler(Node *n) {
    current = MEMBER_VAR;
    Language::membervariableHandler(n);
    current = NO_CPP;
    return SWIG_OK;
  }

  /* -----------------------------------------------------------------------
   * staticmemberfunctionHandler()
   *
   * Wrap a static C++ function
   * ---------------------------------------------------------------------- */

  virtual int staticmemberfunctionHandler(Node *n) {
    current = STATIC_FUNC;
    Language::staticmemberfunctionHandler(n);
    current = NO_CPP;
    return SWIG_OK;
  }
  
  /* ----------------------------------------------------------------------
   * memberconstantHandler()
   *
   * Create a C++ constant
   * --------------------------------------------------------------------- */

  virtual int memberconstantHandler(Node *n) {
    current = CLASS_CONST;
    Language::memberconstantHandler(n);
    current = NO_CPP;
    return SWIG_OK;
  }
  
  /* ---------------------------------------------------------------------
   * staticmembervariableHandler()
   * --------------------------------------------------------------------- */

  virtual int staticmembervariableHandler(Node *n) {
    current = STATIC_VAR;
    Language::staticmembervariableHandler(n);
    current = NO_CPP;
    return SWIG_OK;
  }
  
};  /* class NASAL */
  
/* -----------------------------------------------------------------------------
 * swig_nasal()    - Instantiate module
 * ----------------------------------------------------------------------------- */

extern "C" Language *
swig_nasal(void) {
  return new NASAL();
}


/*
 * Local Variables:
 * c-basic-offset: 2
 * End:
 */

